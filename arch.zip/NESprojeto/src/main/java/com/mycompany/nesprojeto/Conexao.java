package com.mycompany.nesprojeto;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;


public class Conexao {
    
    public static Connection faz_conexao() throws SQLException {
        
     Connection conexao = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conexao = DriverManager.getConnection("jdbc:mysql://localhost:3306/db_senhas", "root", "TavoSouSa3101");
            
            
        } catch (ClassNotFoundException ex) {
            System.out.println("Driver do Banco de Dados Não localizado");
        } catch (SQLException ex) {
            System.out.println("Ocorreu um erro ao aecessar o banco: " + ex.getMessage());
        } 
        return conexao;
        
        
    }
    
    
}
